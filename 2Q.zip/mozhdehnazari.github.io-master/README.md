# Resume template

forked from https://github.com/jglovier/resume-template/